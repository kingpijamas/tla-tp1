Trabajo práctico I de la materia Autómatas, Teoría de Lenguajes y Compiladores
Victoria Mesa Alcorta
Alan Pierri
Juan Pablo Rey
Año 2012

Instrucciones para make
=======================
make tp
	arma el trabajo práctico
make clean
	borra lo armado
cat <archivo> | ./tp
	corre el programa con la entrada del archivo
echo <string> | ./tp
	corre el programa con el string
./tp
	parsea la entrada que se le ingrese
